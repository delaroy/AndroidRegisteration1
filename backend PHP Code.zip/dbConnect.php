<?php
define('HOST','localhost');
define('USER','admin-retrieve');
define('PASS','admin-retrieve');
define('DB','retrieve-data');
$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');

?>